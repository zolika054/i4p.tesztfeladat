﻿using System.Diagnostics.Tracing;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Pálfi_Zoltán_1._feladat
{
    /*
     Ez az első tesztfeladat megoldása, amit Pető Ferenc adott
     */
    internal class Program
    {
        static Dictionary<char, int> tabla = new Dictionary<char, int>()
        {
            {'a',0 },
            {'b',1 },
            {'c',2 },
            {'d',3 },
            {'e',4 },
            {'f',5 },
            {'g',6 },
            {'h',7 },
            {'i',8 },
            {'j',9 },
            {'k',10 },
            {'l',11 },
            {'m',12 },
            {'n',13 },
            {'o',14 },
            {'p',15 },
            {'q',16 },
            {'r',17 },
            {'s',18 },
            {'t',19 },
            {'u',20 },
            {'v',21 },
            {'w',22 },
            {'x',23 },
            {'y',24 },
            {'z',25 },
            {' ',26 }
        };
        static List<int> atlakait(List<char> szoveg)
        { //megkeresi a táblában az adott betűhöz tartozó számot
            List<int> szkod = new List<int>();
            for (int i = 0; i < szoveg.Count; i++)
            {
                szkod.Add(tabla[szoveg[i]]);
                //Console.WriteLine(szkod[i]); tesztkiiras
            }
            return szkod;
        }
        static List<int> atalakit2(List<char> kulcs)
        {//megkeresi a táblában az adott betűhöz tartozó számot
            List<int> kkulcs = new List<int>();
            for (int i = 0; i < kulcs.Count; i++)
            {
                kkulcs.Add(tabla[kulcs[i]]);
                //Console.WriteLine(kkod[i]); tesztkiiras
            }
            return kkulcs;
        }

        static char[] kivetel = { 'á', 'é', 'ó', 'ő', 'ü', 'ö', 'ú', 'ű', 'í' }; //ezek ne legyenek benne a kulcsbam, és a szövegben

        static string rejtjel(List<int> kszoveg, List<int> kkulcs)
        {//hozzáadja az üzenet számához a kulcs számát
            List<int> osszegek = new List<int>();
            for (int i = 0; i < kszoveg.Count; i++)//a két szám összege kitesz egy új karaktert
            {
                int ossz = kszoveg[i] + kkulcs[i];
                if (ossz > 26)
                {
                    osszegek.Add(ossz % 27);
                }
                else
                {
                    osszegek.Add(ossz);
                }
            }
            string ujszoveg = "";
            for (int i = 0; i < osszegek.Count; i++)
            {//új karakter képzés az összegből
                ujszoveg += tabla.FirstOrDefault(x => x.Value == osszegek[i]).Key;
            }
            return ujszoveg;
        }

        static string dekoder(string rüzenet, List<int> kkulcs)
        {//itt a rejtett üzenet dekódolása fog megoldódni
            string eüzenet = "";
            for (int i = 0; i < rüzenet.Length; i++)
            {
                if (tabla[rüzenet[i]] - kkulcs[i] < 0)//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, kisebb érték (x<0), így hozzáadok 27 et és azt keresem vissza
                {
                    eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] + 27 - kkulcs[i])).Key;
                }
                else//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, az így kapott értéket megkeresem a táblában
                {
                    eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] - kkulcs[i])).Key;
                }
            }
            return eüzenet;
        }

        static void Main(string[] args)
        {
            /*
            List<char> szoveg = new List<char>();
            int sv;
            do//megnézem, hogy a szövegben nincs-e benne a tiltott karakterek
            {
                sv = 0;
                Console.Write("Kérem a titkosítandó szöveget (csak angol betűket tartalmazhat): ");
                szoveg = Console.ReadLine().ToCharArray().ToList();
                for (int i = 0; i < szoveg.Count(); i++)
                {
                    for (int j = 0; j < kivetel.Count(); j++)
                    {
                        if (szoveg[i] == kivetel[j])
                        {
                            sv++;
                        }
                    }
                }
            } while (sv!=0);
            List<char> kulcs= new List<char>();
            do//megnézem, hogy a kulcsban nincsen-e benne a tiltott szavak
            {
                sv = 0;
                Console.Write("Kérem a kulcsot (csak angol betűket tartalmazhat): ");
                kulcs = Console.ReadLine().ToCharArray().ToList();
                if (kulcs.Count < szoveg.Count)
                {
                    Console.WriteLine("Kevesebb karaktert tartalmaz a kulcs, mint a kódolandó szöveg!");
                    sv = 1;
                }
                for (int i = 0; i < kulcs.Count(); i++)
                {
                    for (int j = 0; j < kivetel.Count(); j++)
                    {
                        if (kulcs[i] == kivetel[j])
                        {
                            sv++;
                        }
                    }
                }
            } while (sv!=0);
            //átalakítom a szövegeket kóddá
            List<int> kszoveg = atlakait(szoveg);
            List<int> kkod = atalakit2(kulcs);
            Console.WriteLine("Kódolt üzenet: ");
            Console.WriteLine(rejtjel(kszoveg,kkod));
            Console.WriteLine("Dekódolt üzenet: ");
            Console.WriteLine(dekoder(rejtjel(kszoveg,kkod),kkod));*/

            //2. rész
            string uzenet = "curiosity killed the cat";//két titkosítandó szöveg
            string uzenet2 = "early bird catches the worm";
            int uzenet_hossz = (uzenet.Length > uzenet2.Length) ? uzenet.Length : uzenet2.Length;//a kulcs legyen legalább akkora mint az üzenet
            int uzenet_hossz2 = (uzenet.Length > uzenet2.Length) ? uzenet2.Length : uzenet.Length;
            string titkos_kulcs = "";
            while (titkos_kulcs.Length <= uzenet_hossz)
            {//a words.txt ből legenárulnk egy random kulcsot
                Random r = new Random();
                titkos_kulcs += words[r.Next(words.Count())];
            }
            //betitkosítjuk a szöveget a kulcsal, ezeket kell majd feltörni
            string titkos_uzenet = rejtjel(atlakait(uzenet.ToCharArray().ToList()), atalakit2(titkos_kulcs.ToCharArray().ToList()));
            string titkos_uzenet2 = rejtjel(atlakait(uzenet2.ToCharArray().ToList()), atalakit2(titkos_kulcs.ToCharArray().ToList()));
            Console.WriteLine(titkos_uzenet);
            Console.WriteLine(titkos_uzenet2);

            /*string abc = "abcdefghijklmnopqrstuvwxyz";

            int abc_index = 0, kulcs_index = 1;
            string probakulcs = "a";
            /*for (int i = 0; i < uzenet_hossz2; i++)
            {
                probakulcs += abc[0];
            }
            //Console.WriteLine(probakulcs);



            //az elso betut visszuk a-z ig es ha az elso betu z akkor => aa aztan ab, ac, ... az => aaa, aab, aac,
            //ha van a egyezes pl aac, akkor aaca lesz

            //az elso betut visszuk a-z ig es ha az elso betu z akkor => aa,ba,ca,da,

            while (true)
            {
                string dekodolt = dekoder2(titkos_uzenet, probakulcs);
                string dekodolt2=dekoder2(titkos_uzenet2,probakulcs);
                Console.WriteLine(probakulcs);
                if (vanE(dekodolt, probakulcs.Length) && vanE(dekodolt2, probakulcs.Length))
                {
                    if (probakulcs.Length < uzenet_hossz2)
                    {
                        probakulcs += 'a';
                    }
                    if (probakulcs.Length == uzenet_hossz2)
                    {
                        string sv = probakulcs;
                        probakulcs = "";
                        for (int i = 0; i < sv.Length-1; i++)
                        {
                            probakulcs += sv[i];
                        }
                        if (sv.Last() == 'z')
                        {
                            probakulcs += sv[sv.Length];
                            probakulcs += 'a';
                        }
                        else
                        {
                            probakulcs += abc[abc.IndexOf(sv.Last()) + 1];
                        }
                    }
                }
                else
                {
                    if (probakulcs.Length == 1&&probakulcs.Last()!='z')
                    {
                        string sv=probakulcs;
                        probakulcs = "";
                        probakulcs += abc[abc.IndexOf(sv) + 1];
                    }
                    if (probakulcs.Length == 1 && probakulcs[0] == 'z')
                    {
                        probakulcs = "aa";
                        kulcs_index++;
                    }
                    if (probakulcs.Length > 1 && probakulcs.Length < uzenet_hossz2)
                    {
                        string sv = probakulcs;
                        probakulcs = "";
                        for (int i = 0; i < sv.Length-1; i++)
                        {
                            probakulcs += sv[i];
                        }
                        if (sv.Last() == 'z')
                        {
                            probakulcs += "aa";
                            kulcs_index++;
                        }
                        else
                        {
                            probakulcs += abc[abc.IndexOf(sv.Last()) + 1];
                            Console.WriteLine(probakulcs);
                        }
                    }
                }
            }*/

            //kiválasztunk egy szót a txt ből pl cat és ha azzal értelmes töredéket kapunk a szövegekből akkor kiválasztunk
            //mégegyet és ha azzal is akkor így tovább, de ha nem akkor a cat utáni szót cseréljük

            Console.WriteLine("Titkos kulcs!: "+titkos_kulcs);
            Console.WriteLine();
            
            List<string> result=new List<string>();

            for (int i = 0; i < words.Count; i++)
            {
                string dekodolt = dekoder2(titkos_uzenet, words[i]);
                string dekodolt2 = dekoder2(titkos_uzenet2, words[i]);
                //Console.WriteLine(dekodolt);
                //Console.WriteLine(dekodolt2);
                //Console.WriteLine(words[i]);
                if (vanE(dekodolt,dekodolt2))
                {
                    result.Add(words[i]);
                    Console.WriteLine(dekodolt);
                    Console.WriteLine(dekodolt2);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(words[i]);
                    Console.ForegroundColor= ConsoleColor.White;
                }
            }
            Console.WriteLine("resulthossz " + result.Count);

            for (int i = 0; i < result.Count; i++)
            {
                Console.WriteLine(i);
                int j = 0;
                string rövüzi = titkos_uzenet.Substring(result[i].Length);
                string rövüzi2 = titkos_uzenet2.Substring(result[i].Length);
                string probakulcs = "";
                while (probakulcs.Length < uzenet_hossz - result[i].Length)
                {
                   
                    probakulcs += words[j];
                    if (vanE(dekoder2(rövüzi, probakulcs), dekoder2(rövüzi2, probakulcs)))
                    {
                        result[i] += words[0];
                        rövüzi = rövüzi.Substring(probakulcs.Length);
                        rövüzi2 = rövüzi2.Substring(probakulcs.Length);
                    }
                    else
                    {
                        probakulcs.Remove(probakulcs.IndexOf(words[j]), words[j].Length);
                        j++;
                    }
                    if (j == words.Count())
                    {
                        j = 0;
                    }
                    if(probakulcs.Length >= uzenet_hossz - result[i].Length)
                    {
                        result[i] += probakulcs;
                    }
                }
            }

            for (int i = 0; i < result.Count; i++)
            {
                Console.WriteLine(result[i]); ;
                //Console.WriteLine(dekoder2(titkos_uzenet, result[i]));
                //Console.WriteLine(dekoder2(titkos_uzenet2, result[i]));
            }
        }

        //ha a kulcs vanE akkor le kell vonni a titkositotboll azt a betut amekkora a kulcs[i]
        /*static string joeakulcs(List<string> kulcs,string titkos_uzenet,string titkos_uzenet2)
        {
            for (int i = 0; i < kulcs.Count; i++)
            {
                for (int j = 0; j < words.Count; j++)
                {
                    string probakulcs =words[j];
                    string dekodolt = dekoder2(titkos_uzenet, probakulcs);
                    string dekodolt2 = dekoder2(titkos_uzenet2, probakulcs);
                    if (vanE(dekodolt, probakulcs.Length) && vanE(dekodolt2, probakulcs.Length))
                    {
                        //Console.WriteLine(kulcs[i]);
                        kulcs[i] += probakulcs;
                    }
                }
            }
            for (int i = 0; i < kulcs.Count; i++)
            {
                return kulcs[i];
            }
            return "FATAKERRPUIFGSAU";
        }*/

        static List<string> words = File.ReadAllLines("words.txt").Where(x => x.Length > 1).ToList();//betöltjük a words.txt-t egy listába

        static bool vanE(string uzenet,string uzenet2)
        {
            string[] uzi = uzenet.Split(' ');
            string[] uzi2=uzenet2.Split(' ');
            List<int> sv=new List<int>();
            for (int i = 0; i < uzi.Length; i++)
            {
                List<string> azonos_hosszak = new List<string>();
                for (int l = 0; l < words.Count; l++)
                {
                    if (words[l].Length == uzi[i].Length)
                    {
                        azonos_hosszak.Add(words[l]);
                    }
                }
                for (int j = 0; j < azonos_hosszak.Count; j++)
                {
                    for (int z = 0; z < azonos_hosszak[j].Length; z++)
                    {
                        if (uzi[i][z] == azonos_hosszak[j][z])
                        {
                            sv.Add(1);
                        }
                        else
                        {
                            sv.Add(0);
                        }
                    }
                }
            }
            if (sv.Contains(0))
            {
                return false;
            }
            sv.Clear();
            for (int i = 0; i < uzi2.Length; i++)
            {
                List<string> azonos_hosszak = new List<string>();
                for (int l = 0; l < words.Count; l++)
                {
                    if (words[l].Length == uzi2[i].Length)
                    {
                        azonos_hosszak.Add(words[l]);
                    }
                }
                for (int j = 0; j < azonos_hosszak.Count; j++)
                {
                    for (int z = 0; z < azonos_hosszak[j].Length; z++)
                    {
                        if (uzi2[i][z] == azonos_hosszak[j][z])
                        {
                            sv.Add(1);
                        }
                        else
                        {
                            sv.Add(0);
                        }
                    }
                }
            }
            if (sv.Contains(0))
            {
                return false;
            }

            return true;
        }
        static string dekoder2(string rüzenet, string kulcs)
        {//itt a 2. feladat dekódolása fog történni
            string eüzenet = "";
            List<int> kkulcs = atalakit2(kulcs.ToCharArray().ToList());
            if (rüzenet.Length>kulcs.Length)
            {
                for (int i = 0; i < kkulcs.Count; i++)
                {
                    //Console.WriteLine("rüzenet"+rüzenet.Length);
                    //Console.WriteLine("kulcs"+kkulcs.Count);
                
                    if (tabla[rüzenet[i]] - kkulcs[i] < 0)//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, kisebb érték (x<0), így hozzáadok 27 et és azt keresem vissza
                    {
                        eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] + 27 - kkulcs[i])).Key;
                    }
                    else//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, az így kapott értéket megkeresem a táblában
                    {
                        eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] - kkulcs[i])).Key;
                    }
                }
            }
            else if(rüzenet.Length < kulcs.Length)
            {
                for (int i = 0; i < rüzenet.Length; i++)
                {
                    //Console.WriteLine("rüzenet"+rüzenet.Length);
                    //Console.WriteLine("kulcs"+kkulcs.Count);

                    if (tabla[rüzenet[i]] - kkulcs[i] < 0)//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, kisebb érték (x<0), így hozzáadok 27 et és azt keresem vissza
                    {
                        eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] + 27 - kkulcs[i])).Key;
                    }
                    else//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, az így kapott értéket megkeresem a táblában
                    {
                        eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] - kkulcs[i])).Key;
                    }
                }
            }
            return eüzenet;
        }
    }
}

