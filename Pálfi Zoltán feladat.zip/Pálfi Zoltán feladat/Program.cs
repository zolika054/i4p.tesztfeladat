﻿namespace Pálfi_Zoltán_1._feladat
{
    /*
     Ez az első tesztfeladat megoldása, amit Pető Ferenc adott
     */
    internal class Program
    {
        static Dictionary<char, int> tabla = new Dictionary<char, int>()
        {
            {'a',0 },
            {'b',1 },
            {'c',2 },
            {'d',3 },
            {'e',4 },
            {'f',5 },
            {'g',6 },
            {'h',7 },
            {'i',8 },
            {'j',9 },
            {'k',10 },
            {'l',11 },
            {'m',12 },
            {'n',13 },
            {'o',14 },
            {'p',15 },
            {'q',16 },
            {'r',17 },
            {'s',18 },
            {'t',19 },
            {'u',20 },
            {'v',21 },
            {'w',22 },
            {'x',23 },
            {'y',24 },
            {'z',25 },
            {' ',26 }
        };
        static List<int> atlakait(List<char> szoveg)
        { //megkeresi a táblában az adott betűhöz tartozó számot
            List<int> szkod = new List<int>();
            for (int i = 0; i < szoveg.Count; i++)
            {
                szkod.Add(tabla[szoveg[i]]);
                //Console.WriteLine(szkod[i]); tesztkiiras
            }
            return szkod;
        }
        static List<int> atalakit2 (List<char> kulcs)
        {//megkeresi a táblában az adott betűhöz tartozó számot
            List<int> kkulcs = new List<int>();
            for (int i = 0; i < kulcs.Count; i++)
            {
                kkulcs.Add(tabla[kulcs[i]]);
                //Console.WriteLine(kkod[i]); tesztkiiras
            }
            return kkulcs;
        }

        static char[] kivetel = { 'á', 'é', 'ó', 'ő', 'ü', 'ö', 'ú', 'ű', 'í' }; //ezek ne legyenek benne a kulcsbam, és a szövegben

        static string rejtjel(List<int> kszoveg,List<int> kkulcs)
        {//hozzáadja az üzenet számához a kulcs számát
            List<int> osszegek= new List<int>();
            for (int i = 0;i < kszoveg.Count;i++)//a két szám összege kitesz egy új karaktert
            {
                int ossz = kszoveg[i] + kkulcs[i];
                if (ossz > 26)
                {
                    osszegek.Add(ossz % 27);
                }
                else
                {
                    osszegek.Add(ossz);
                }
            }
            string ujszoveg = "";
            for (int i = 0; i<osszegek.Count; i++)
            {//új karakter képzés az összegből
                ujszoveg += tabla.FirstOrDefault(x => x.Value == osszegek[i]).Key;
            }
            return ujszoveg;
        }

        static string dekoder(string rüzenet,List<int> kkulcs)
        {//itt a rejtett üzenet dekódolása fog megoldódni
            string eüzenet = "";
            for (int i = 0; i < rüzenet.Length; i++)
            {
                if (tabla[rüzenet[i]] - kkulcs[i] < 0)//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, kisebb érték (x<0), így hozzáadok 27 et és azt keresem vissza
                {
                    eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] + 27 - kkulcs[i])).Key;
                }
                else//megkeresem a táblában az rüzenet értékét, majd abból kivonom a kulcs értékét, az így kapott értéket megkeresem a táblában
                {
                    eüzenet += tabla.FirstOrDefault(x => x.Value == (tabla[rüzenet[i]] - kkulcs[i])).Key;
                }
            }
            return eüzenet;
        }

        static void Main(string[] args)
        {

            List<char> szoveg = new List<char>();
            int sv;
            do//megnézem, hogy a szövegben nincs-e benne a tiltott karakterek
            {
                sv = 0;
                Console.Write("Kérem a titkosítandó szöveget (csak angol betűket tartalmazhat): ");
                szoveg = Console.ReadLine().ToCharArray().ToList();
                for (int i = 0; i < szoveg.Count(); i++)
                {
                    for (int j = 0; j < kivetel.Count(); j++)
                    {
                        if (szoveg[i] == kivetel[j])
                        {
                            sv++;
                        }
                    }
                }
            } while (sv!=0);
            List<char> kulcs= new List<char>();
            do//megnézem, hogy a kulcsban nincsen-e benne a tiltott szavak
            {
                sv = 0;
                Console.Write("Kérem a kulcsot (csak angol betűket tartalmazhat): ");
                kulcs = Console.ReadLine().ToCharArray().ToList();
                if (kulcs.Count < szoveg.Count)
                {
                    Console.WriteLine("Kevesebb karaktert tartalmaz a kulcs, mint a kódolandó szöveg!");
                    sv = 1;
                }
                for (int i = 0; i < kulcs.Count(); i++)
                {
                    for (int j = 0; j < kivetel.Count(); j++)
                    {
                        if (kulcs[i] == kivetel[j])
                        {
                            sv++;
                        }
                    }
                }
            } while (sv!=0);
            //átalakítom a szövegeket kóddá
            List<int> kszoveg = atlakait(szoveg);
            List<int> kkod = atalakit2(kulcs);
            Console.WriteLine("Kódolt üzenet: ");
            Console.WriteLine(rejtjel(kszoveg,kkod));
            Console.WriteLine("Dekódolt üzenet: ");
            Console.WriteLine(dekoder(rejtjel(kszoveg,kkod),kkod));
        }
    }
}
